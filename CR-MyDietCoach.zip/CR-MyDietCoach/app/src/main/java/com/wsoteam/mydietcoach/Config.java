package com.wsoteam.mydietcoach;

public class Config {
    public static final String ID_SECTIONS_ARGS = "id_sec_args";
    public static final String ID_SUBSECTIONS_ARGS= "id_sub_sec_args";
    public static final String ID_ITEM= "id_item";
    public static int INDEX_ADMOB = 0;
}
